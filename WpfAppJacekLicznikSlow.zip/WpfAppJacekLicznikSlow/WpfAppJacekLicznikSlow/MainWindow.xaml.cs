﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppJacekLicznikSlow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void licz_Click(object sender, RoutedEventArgs e)
        {
            string text = poleedycji.Text;

            int minslowa = 400;

            int iloscslow = Liczslowa(text);

            int ilebrakuje = minslowa - iloscslow;

            Info.Text = $"Ilość słow: {iloscslow}, \n Brakuje słów: {Math.Max(0,ilebrakuje)}";


            if(iloscslow >= minslowa )
            {
                tekstzmienny.Text = "Jest idealnie";
                image2.Visibility = Visibility.Hidden;
                image1.Visibility = Visibility.Visible;
            }
            else if (iloscslow == 0 )
            {
                tekstzmienny.Text = "Nie wpisałes tekstu";
                image1.Visibility = Visibility.Hidden;
                image2.Visibility = Visibility.Visible;
            }
            else
            {
                tekstzmienny.Text = "Rozprawka powinna zawierac min 400 słów";
                image1.Visibility= Visibility.Hidden;
                image2.Visibility= Visibility.Visible;
            }

        }
        private int Liczslowa(string text)
        {
            var slowa = text.Split(new[] { ' ', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            return slowa.Length;
        }
    }
}